import text2img from "./text2img.js";

export default [text2img];
