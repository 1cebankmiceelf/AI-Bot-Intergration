---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

<!-- Please fill out these fields -->

**Describe the feature**
A clear and concise description of the feature.

**Why do you think this feature should be implemented?**
What does it solve?

**Additional context**
Add any other context or screenshots about the feature request here.
